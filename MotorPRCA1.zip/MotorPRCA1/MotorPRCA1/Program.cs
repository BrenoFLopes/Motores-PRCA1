﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorPRCA1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] custo;
            custo = new double[15]; //15 motores array
            int opçao;
            int motor;
            double total;

            do
            {
                Console.WriteLine("-------------------");
                Console.WriteLine("MENU DE ACESSO");
                Console.WriteLine("0. SAIR");
                Console.WriteLine("1. LANÇAR VALOR");
                Console.WriteLine("2. MOSTRAR VALORES DOS MOTORES");
                Console.WriteLine("-------------------");
                Console.Write("Insira a opção desejada: ");
                opçao = int.Parse(Console.ReadLine());

                if (opçao == 1) //1. LANÇAR VALOR
                {
                    do
                    {
                        Console.Write("Insira o nº do motor desejado: ");
                        motor = int.Parse(Console.ReadLine());
                    }
                    while ((motor < 1) || (motor > 15));
                    Console.Write("Insira o valor do motor: R$");
                    custo[motor - 1] = double.Parse(Console.ReadLine());
                    Console.WriteLine("Valor inserido com sucesso!"); // UX                 
                }
                else
                {
                    if (opçao == 2) //2. MOSTRAR VALORES DOS MOTORES
                    {
                        total = 0; //zerar contador total
                        for (motor = 0; motor < 15; motor++)  //Contador ++
                        {
                            Console.WriteLine("Motor {0} --> R${1}", motor + 1, custo[motor]);
                            total += custo[motor];
                        }
                        Console.WriteLine("------------------");
                        Console.WriteLine("TOTAL: R$ {0}", total);
                    }
                }
            }
            while (opçao != 0); //se opção=0 -> sair. ------- 0. SAIR
        }
    }
}
